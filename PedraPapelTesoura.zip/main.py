import random


def play():
  user = input(
      "Qual a sua escolha? 'r' for rock, 'p' for paper, 's' for scissors\n")
  computer = random.choice(['r', 'p', 's'])
  print("A escolha do oponente é : ", computer)

  if user == computer:
    return 'Empate!'
  #r > s, s> p, p> r
  if is_win(user, computer):
    return 'Vitória!'

  return 'Derrota!'


def is_win(player, opponent):
  #retornar verdadeiro
  #r > s, s> p, p> r
  if ((player == 'r' and opponent == 's')
      or (player == 's' and opponent == 'p')
      or (player == 'p' and opponent == 'r')):
    return True


print(play())
